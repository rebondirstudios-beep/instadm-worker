var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[root-of-the-server]__93691565._.js")
R.c("server/chunks/[root-of-the-server]__c94de7c8._.js")
R.c("server/chunks/node_modules_next_dist_03fe560d._.js")
R.m(93935)
module.exports=R.m(93935).exports
