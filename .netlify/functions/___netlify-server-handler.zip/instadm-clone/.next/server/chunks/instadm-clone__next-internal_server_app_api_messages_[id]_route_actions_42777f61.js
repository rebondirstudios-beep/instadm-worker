module.exports=[51163,(e,o,d)=>{}];

//# sourceMappingURL=instadm-clone__next-internal_server_app_api_messages_%5Bid%5D_route_actions_42777f61.js.map