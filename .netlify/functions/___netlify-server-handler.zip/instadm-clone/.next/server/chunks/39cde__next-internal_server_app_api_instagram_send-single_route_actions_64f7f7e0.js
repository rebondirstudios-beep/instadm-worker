module.exports=[37591,(e,o,d)=>{}];

//# sourceMappingURL=39cde__next-internal_server_app_api_instagram_send-single_route_actions_64f7f7e0.js.map