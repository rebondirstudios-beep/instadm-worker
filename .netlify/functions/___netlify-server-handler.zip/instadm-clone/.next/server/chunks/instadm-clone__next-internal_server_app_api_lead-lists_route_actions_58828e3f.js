module.exports=[31210,(e,o,d)=>{}];

//# sourceMappingURL=instadm-clone__next-internal_server_app_api_lead-lists_route_actions_58828e3f.js.map