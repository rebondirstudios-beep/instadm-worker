module.exports=[59981,(e,o,d)=>{}];

//# sourceMappingURL=39cde__next-internal_server_app_api_automation_send-messages_route_actions_e5b68f46.js.map