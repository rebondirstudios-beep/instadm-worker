module.exports=[13104,(e,o,d)=>{}];

//# sourceMappingURL=instadm-clone__next-internal_server_app_api_accounts_%5Bid%5D_route_actions_92bf811a.js.map