module.exports=[34682,(e,o,d)=>{}];

//# sourceMappingURL=39cde__next-internal_server_app_api_campaigns_%5Bid%5D_messages_route_actions_e41cb727.js.map