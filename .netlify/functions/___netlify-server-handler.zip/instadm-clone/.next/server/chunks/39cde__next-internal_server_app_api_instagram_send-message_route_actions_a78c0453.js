module.exports=[77453,(e,o,d)=>{}];

//# sourceMappingURL=39cde__next-internal_server_app_api_instagram_send-message_route_actions_a78c0453.js.map