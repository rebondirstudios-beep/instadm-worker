module.exports=[24047,a=>a.a(async(c,t)=>{try{let c=await a.y("playwright-9b51c99ca474dcf1");a.n(c),t()}catch(a){t(a)}},!0)];

//# sourceMappingURL=%5Bexternals%5D_playwright_3934a698._.js.map