module.exports=[55035,(e,o,d)=>{}];

//# sourceMappingURL=instadm-clone__next-internal_server_app_api_campaigns_route_actions_96e347f3.js.map