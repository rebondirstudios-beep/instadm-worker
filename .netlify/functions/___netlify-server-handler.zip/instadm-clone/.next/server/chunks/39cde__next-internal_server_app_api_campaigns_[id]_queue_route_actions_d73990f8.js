module.exports=[50483,(e,o,d)=>{}];

//# sourceMappingURL=39cde__next-internal_server_app_api_campaigns_%5Bid%5D_queue_route_actions_d73990f8.js.map