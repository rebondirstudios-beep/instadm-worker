module.exports=[27825,(e,o,d)=>{}];

//# sourceMappingURL=39cde__next-internal_server_app_api_templates_%5Bid%5D_route_actions_f1751c33.js.map