module.exports=[4577,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},23239,a=>{"use strict";let b={src:a.i(4577).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=instadm-clone_src_app_21f06a25._.js.map