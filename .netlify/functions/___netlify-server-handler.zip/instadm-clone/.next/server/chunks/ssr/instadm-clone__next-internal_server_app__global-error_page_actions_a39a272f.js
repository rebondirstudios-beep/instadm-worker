module.exports=[29696,(a,b,c)=>{}];

//# sourceMappingURL=instadm-clone__next-internal_server_app__global-error_page_actions_a39a272f.js.map