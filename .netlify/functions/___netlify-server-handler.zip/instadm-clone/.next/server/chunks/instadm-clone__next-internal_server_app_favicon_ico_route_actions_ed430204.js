module.exports=[90694,(e,o,d)=>{}];

//# sourceMappingURL=instadm-clone__next-internal_server_app_favicon_ico_route_actions_ed430204.js.map