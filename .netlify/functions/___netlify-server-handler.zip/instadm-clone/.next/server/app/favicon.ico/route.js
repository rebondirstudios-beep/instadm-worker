var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0b7f0a8f.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/instadm-clone__next-internal_server_app_favicon_ico_route_actions_ed430204.js")
R.m(66563)
module.exports=R.m(66563).exports
