var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/campaigns/[id]/queue/route.js")
R.c("server/chunks/[root-of-the-server]__e03a051d._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_eec6de98._.js")
R.c("server/chunks/39cde__next-internal_server_app_api_campaigns_[id]_queue_route_actions_d73990f8.js")
R.m(11120)
module.exports=R.m(11120).exports
