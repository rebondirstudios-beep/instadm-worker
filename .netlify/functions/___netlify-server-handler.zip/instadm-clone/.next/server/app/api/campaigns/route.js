var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/campaigns/route.js")
R.c("server/chunks/[root-of-the-server]__79a51990._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_eec6de98._.js")
R.c("server/chunks/instadm-clone__next-internal_server_app_api_campaigns_route_actions_96e347f3.js")
R.m(10617)
module.exports=R.m(10617).exports
