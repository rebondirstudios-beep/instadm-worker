var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/accounts/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__734b1fe6._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_eec6de98._.js")
R.c("server/chunks/instadm-clone__next-internal_server_app_api_accounts_[id]_route_actions_92bf811a.js")
R.m(95685)
module.exports=R.m(95685).exports
