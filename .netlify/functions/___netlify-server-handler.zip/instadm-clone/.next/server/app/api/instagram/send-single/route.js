var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/instagram/send-single/route.js")
R.c("server/chunks/[root-of-the-server]__9cbc9897._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_eec6de98._.js")
R.c("server/chunks/39cde__next-internal_server_app_api_instagram_send-single_route_actions_64f7f7e0.js")
R.m(20665)
module.exports=R.m(20665).exports
