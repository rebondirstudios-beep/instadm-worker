var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/instagram/humanized-send/route.js")
R.c("server/chunks/[root-of-the-server]__155652d6._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_1877c8de.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_eec6de98._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/39cde__next-internal_server_app_api_instagram_humanized-send_route_actions_8255f88e.js")
R.m(28371)
module.exports=R.m(28371).exports
