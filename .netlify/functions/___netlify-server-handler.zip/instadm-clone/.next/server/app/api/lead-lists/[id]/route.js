var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/lead-lists/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__e58e0010._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_eec6de98._.js")
R.c("server/chunks/39cde__next-internal_server_app_api_lead-lists_[id]_route_actions_54c3d633.js")
R.m(14613)
module.exports=R.m(14613).exports
