var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/messages/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__c390e84a._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_eec6de98._.js")
R.c("server/chunks/instadm-clone__next-internal_server_app_api_messages_[id]_route_actions_42777f61.js")
R.m(81007)
module.exports=R.m(81007).exports
