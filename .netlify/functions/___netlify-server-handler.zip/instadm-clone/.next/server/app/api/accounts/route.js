var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/accounts/route.js")
R.c("server/chunks/[root-of-the-server]__b2e19a72._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_eec6de98._.js")
R.c("server/chunks/instadm-clone__next-internal_server_app_api_accounts_route_actions_2a77e04c.js")
R.m(62675)
module.exports=R.m(62675).exports
