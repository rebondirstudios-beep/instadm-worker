var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/templates/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__b940631d._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_eec6de98._.js")
R.c("server/chunks/39cde__next-internal_server_app_api_templates_[id]_route_actions_f1751c33.js")
R.m(7779)
module.exports=R.m(7779).exports
