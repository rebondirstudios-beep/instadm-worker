var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/instagram/send-message/route.js")
R.c("server/chunks/[root-of-the-server]__4bff8303._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_eec6de98._.js")
R.c("server/chunks/39cde__next-internal_server_app_api_instagram_send-message_route_actions_a78c0453.js")
R.m(70182)
module.exports=R.m(70182).exports
