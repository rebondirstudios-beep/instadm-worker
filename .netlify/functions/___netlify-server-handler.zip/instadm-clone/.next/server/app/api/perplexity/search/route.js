var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/perplexity/search/route.js")
R.c("server/chunks/[root-of-the-server]__5f8169f6._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_eec6de98._.js")
R.c("server/chunks/39cde__next-internal_server_app_api_perplexity_search_route_actions_09a471cd.js")
R.m(35553)
module.exports=R.m(35553).exports
