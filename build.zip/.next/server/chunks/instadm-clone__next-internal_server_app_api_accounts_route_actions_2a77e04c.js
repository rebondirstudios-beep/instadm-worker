module.exports=[17272,(e,o,d)=>{}];

//# sourceMappingURL=instadm-clone__next-internal_server_app_api_accounts_route_actions_2a77e04c.js.map