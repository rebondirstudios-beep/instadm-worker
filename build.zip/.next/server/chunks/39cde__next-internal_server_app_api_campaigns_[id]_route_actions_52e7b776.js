module.exports=[69668,(e,o,d)=>{}];

//# sourceMappingURL=39cde__next-internal_server_app_api_campaigns_%5Bid%5D_route_actions_52e7b776.js.map