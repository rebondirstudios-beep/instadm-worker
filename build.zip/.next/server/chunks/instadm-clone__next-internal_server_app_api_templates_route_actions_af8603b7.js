module.exports=[87999,(e,o,d)=>{}];

//# sourceMappingURL=instadm-clone__next-internal_server_app_api_templates_route_actions_af8603b7.js.map