var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/leads/import/route.js")
R.c("server/chunks/[root-of-the-server]__73276291._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/instadm-clone__next-internal_server_app_api_leads_import_route_actions_a1726965.js")
R.m(40056)
module.exports=R.m(40056).exports
