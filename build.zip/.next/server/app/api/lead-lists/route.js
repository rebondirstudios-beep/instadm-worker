var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/lead-lists/route.js")
R.c("server/chunks/[root-of-the-server]__907fb856._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_eec6de98._.js")
R.c("server/chunks/instadm-clone__next-internal_server_app_api_lead-lists_route_actions_58828e3f.js")
R.m(90207)
module.exports=R.m(90207).exports
