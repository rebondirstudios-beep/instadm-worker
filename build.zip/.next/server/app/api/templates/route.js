var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/templates/route.js")
R.c("server/chunks/[root-of-the-server]__ce301bff._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_eec6de98._.js")
R.c("server/chunks/instadm-clone__next-internal_server_app_api_templates_route_actions_af8603b7.js")
R.m(13077)
module.exports=R.m(13077).exports
