var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/google-sheets/push/route.js")
R.c("server/chunks/[root-of-the-server]__875aadf7._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_eec6de98._.js")
R.c("server/chunks/39cde__next-internal_server_app_api_google-sheets_push_route_actions_d47bade8.js")
R.m(7536)
module.exports=R.m(7536).exports
