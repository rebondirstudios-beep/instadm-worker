var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/campaigns/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__c8899126._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_eec6de98._.js")
R.c("server/chunks/39cde__next-internal_server_app_api_campaigns_[id]_route_actions_52e7b776.js")
R.m(26855)
module.exports=R.m(26855).exports
