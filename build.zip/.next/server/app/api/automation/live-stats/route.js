var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/automation/live-stats/route.js")
R.c("server/chunks/[root-of-the-server]__4297a273._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_eec6de98._.js")
R.c("server/chunks/39cde__next-internal_server_app_api_automation_live-stats_route_actions_59c354bb.js")
R.m(6211)
module.exports=R.m(6211).exports
