var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/automation/status/route.js")
R.c("server/chunks/[root-of-the-server]__f17793cd._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_eec6de98._.js")
R.c("server/chunks/39cde__next-internal_server_app_api_automation_status_route_actions_e917c07f.js")
R.m(55304)
module.exports=R.m(55304).exports
