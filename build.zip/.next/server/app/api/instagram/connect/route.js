var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/instagram/connect/route.js")
R.c("server/chunks/[root-of-the-server]__77e97a43._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__d7355d04._.js")
R.c("server/chunks/_eec6de98._.js")
R.c("server/chunks/39cde__next-internal_server_app_api_instagram_connect_route_actions_aa915dc4.js")
R.m(48732)
module.exports=R.m(48732).exports
